const db = require('better-sqlite3')('./database.sqlite');

module.exports = {
    db,
};