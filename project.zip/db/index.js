const adminDb = require('./admin.db');
const clientDb = require('./client.db');

module.exports = {
  adminDb,
  clientDb,
};
