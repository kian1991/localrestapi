const adminController = require('./admin.controller');
const clientController = require('./client.controller');

module.exports = {
  adminController,
  clientController,
};
