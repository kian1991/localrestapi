const adminService = require('./admin.service');
const clientService = require('./client.service');

module.exports = {
  adminService,
  clientService,
};
